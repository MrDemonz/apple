好多小伙伴私我要RegDB数据集
这里放出来：

1、这里是数据集出处：
Nguyen Dat Tien, Hong Hyung Gil, Kim Ki Wan, et al. Person Recognition System Based on a Combination of Body Images from Visible Light and Thermal Cameras.. 2017, 17(3)

神奇的地方是，最早这个数据集的提出并不是为了解决跨模态的gap问题的：
作者认为采用热图像可以减少噪声、背景及行人外观变化带来的负面影响，可以用于辅助RGB图像中行人重识别任务。

2、这里是我从文章里翻译的数据集RegDB的介绍：
数据集RegDB包含了412个行人身份，每个行人收集了10张RGB图像和10张IR图像，其中有254个女性和158个男性，并且412个人中有156个人是从正面拍摄，256个人从背面拍摄。但是该数据集图像小，清晰度较差，每个身份的RGB图像和热图的姿态都是一一对应的，并且同一个身份在姿态上变化很小，这些因素都降低了该数据集RegDB上的跨模态行人重识别任务的难度。

3、最后：
祝大家科研成功
欢迎点赞评论交流！